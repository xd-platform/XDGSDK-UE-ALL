//
//  XDGLoginEntriesConfig.h
//  XDAccountSDK
//
//  Created by Fattycat on 2022/6/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XDGLoginEntriesConfig : NSObject
@property (nonatomic, strong) NSMutableArray<NSString *> *loginEntryList;
@end

NS_ASSUME_NONNULL_END
