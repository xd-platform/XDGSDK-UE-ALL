
//  tap风格主要按钮

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XDGMainButton : UIButton

@property(nonatomic, assign)BOOL clearBG;

- (void)setButtonEnable:(BOOL)enable;

@end

NS_ASSUME_NONNULL_END
