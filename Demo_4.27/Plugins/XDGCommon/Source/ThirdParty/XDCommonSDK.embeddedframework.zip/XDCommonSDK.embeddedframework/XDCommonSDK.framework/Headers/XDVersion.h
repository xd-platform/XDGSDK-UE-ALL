//
//  XDVersion.h
//  XDCommonSDK
//
//  Created by Fattycat on 2022/5/13.
//

#define XDSDK_VERSION @"6.5.0"
