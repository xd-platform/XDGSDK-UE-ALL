//
//  XDThirdTrackSDK.h
//  XDThirdTrackSDK
//
//  Created by Fattycat on 2022/5/26.
//

#import <Foundation/Foundation.h>

//! Project version number for XDThirdTrackSDK.
FOUNDATION_EXPORT double XDThirdTrackSDKVersionNumber;

//! Project version string for XDThirdTrackSDK.
FOUNDATION_EXPORT const unsigned char XDThirdTrackSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <XDThirdTrackSDK/PublicHeader.h>


